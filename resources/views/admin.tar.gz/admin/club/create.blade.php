@extends('adminMaster')


@section('adminContent')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center><b>Add Player</b></center></div>

                    <div class="panel-body">
                            {!! Form::open(['route'=>'clubs.store'])!!}
                            <fieldset>
                               
                                 <div class="form-group">
                                     <label><b>PLAYER NAME</b></label>
                                     {!! Form::text('name',null,array('class'=>'form-control')) !!}
                                 </div>
                                 <div class="form-group">
                                     <label><b>DOB</b></label>
                                     {!! Form::text('est_date',null,array('class'=>'form-control')) !!}
                                 </div>
                                 <div class="form-group">
                                     <label><b>PERMANENT ADDRESS</b></label>
                                     {!! Form::text('CEO',null,array('class'=>'form-control')) !!}

                                 </div>
                                 <div class="form-group">
                                      <label><b>TEMPORARY ADDRESS</b></label>
                                      {!! Form::text('location',null,array('class'=>'form-control')) !!}

                                 </div>

                                <div class="form-group">
                                     <label><b>BLOOD GROUP</b></label>
                                     {!! Form::text('contact_no',null,array('class'=>'form-control')) !!}

                                </div>
                               <div class="form-group">
                                    <label><b>HEIGHT</b></label>
                                    {!! Form::text('email_id',null,array('class'=>'form-control'))!!}
                                </div>
                                <div class="form-group">
                                    <label><b>WEIGHT</b></label>
                                    {!! Form::text('website',null,array('class'=>'form-control'))!!}
                                </div>
                                
                                <br><br>
                                <center>{!! form::submit('Add Club',[' class'=>'btn btn-primary form-control'])!!}</center>

                            </fieldset>
                        {!! Form::close()!!}
                    </div>
                </div>

        </div>
    </div>
</div><!-- /col-lg-9 END SECTION MIDDLE -->
@stop

