@extends('adminMaster')


@section('adminContent')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center><b>Add Player</b></center></div>

                    <div class="panel-body">
                            {!! Form::open(['route'=>'playerhistories.store'])!!}
                            <fieldset>
                               
                                <div>
                                    <label><b>CLUB</b></label>
                                    <select class="form-control" name="player_id">
                                              @foreach($players as $player)
                                                <option value="{{$player->id}}">{{$player->name}}</option>
                                              @endforeach
                                    </select>
                                </div>
                               
                                 
                                <br><br>
                                <center>{!! form::submit('Add Club',[' class'=>'btn btn-primary form-control'])!!}</center>

                            </fieldset>
                        {!! Form::close()!!}
                    </div>
                </div>

        </div>
    </div>
</div><!-- /col-lg-9 END SECTION MIDDLE -->
@stop

