@extends('adminMaster')

@section('breadcrumb')
    <h3 class="panel-title">Albums</h3>
    <div class="sub-menu">
        <a href="{{url('players/create')}}"><i class="fa fa-plus-circle fa-2x pull-right">add</i></a>
    </div>
   
@stop
@section('adminContent')
  

                       <table class="table table-hover table-striped">
                          <thead>
                             
                                 
                                  <th >Player Name</th>
                                  <th >DOB</th>
                                  <th >P. Address</th>                             
                                  <th >Height</th>
                                  <th>Height</th>
                                  <th >Complexion</th>                                 
                                  <th >Club</th>
                                  <th width="10">Edit</th>
                                  <th width="10">Delete</th>
                              
                          </thead>
                          <tbody>
                        
                               
                          </tbody>
                      </table>
                 

   </div><!-- /col-lg-9 END SECTION MIDDLE -->
@stop
@section('js_code')

@stop

