@extends('adminMaster')


@section('adminContent')
  

                       <table class="table table-hover table-striped">
                          <thead>
                             
                                 
                                  <th >Player Name</th>
                                  <th >DOB</th>
                                  <th >P. Address</th>                             
                                  
                                  <th >Height</th>
                                  <th>Height</th>
                                  <th >Complexion</th>                                 
                                  <th >Club</th>
                                  
                                  


                                  
                                 
                              
                          </thead>
                          <tbody>
                        
                                @foreach($players as $player)
                                  <tr>
                                <td>{!!$player->name !!}</td>
                                <td>{!!$player->DOB !!}</td>
                                <td>{!!$player->permanent_address!!}</td>
                                <td>{!!$player->height !!}</td>
                                <td>{!!$player->weight !!}</td>
                                <td>{!!$player->complexion !!}</td>
                                <td>{!!$player->club->name !!}</td>
                                <td>{!! link_to_route('players.edit', '', array($player->id),array('class' => 'fa fa-external-link')) !!}</td>
                               <td>{!! link_to_route('players.edit', '', array($player->id),array('class' => 'fa fa-paper-plane-o')) !!}</td>
                               
                                
                                </tr>
                                @endforeach
                          
                          </tbody>
                      </table>
                 

   </div><!-- /col-lg-9 END SECTION MIDDLE -->
@stop
@section('js_code')

@stop

