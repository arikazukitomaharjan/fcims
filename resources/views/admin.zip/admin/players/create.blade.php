@extends('adminMaster')


@section('adminContent')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><center><b>Add Player</b></center></div>

                    <div class="panel-body">
                         
                        {!! Form::open(['route'=>'players.store'])!!}
                            <fieldset>
                           
                               <div class="col-md-6">
                                     <div class="form-group">
                                         <label><b>PLAYER NAME</b></label>
                                         {!! Form::text('name',null,array('class'=>'form-control')) !!}
                                     </div>
                                     <div class="form-group">
                                         <label><b>DOB</b></label>
                                         {!! Form::text('DOB',null,array('class'=>'form-control')) !!}
                                     </div>
                                     <div class="form-group">
                                         <label><b>PERMANENT ADDRESS</b></label>
                                         {!! Form::text('permanent_address',null,array('class'=>'form-control')) !!}

                                     </div>
                                     <div class="form-group">
                                          <label><b>TEMPORARY ADDRESS</b></label>
                                          {!! Form::text('temporary_address',null,array('class'=>'form-control')) !!}

                                     </div>

                                    <div class="form-group">
                                         <label><b>BLOOD GROUP</b></label>
                                         {!! Form::text('blood_group',null,array('class'=>'form-control')) !!}

                                    </div>
                                    
                                </div>
                                  <div claSS="col-md-6 pull-right">
                                   <div class="form-group">
                                        <label><b>HEIGHT</b></label>
                                        {!! Form::text('height',null,array('class'=>'form-control'))!!}
                                    </div>
                                    <div class="form-group">
                                        <label><b>WEIGHT</b></label>
                                        {!! Form::text('weight',null,array('class'=>'form-control'))!!}
                                    </div>
                                    <div class="form-group">
                                        <label><b>COMPLEXION</b></label>
                                        {!! Form::text('complexion',null,array('class'=>'form-control'))!!}
                                    </div>
                                    <div>
                                        <label><b>CLUB</b></label>
                                        <select class="form-control" name="club_id">
                                                  @foreach($club as $club)
                                                    <option value="{{$club->id}}">{{$club->name}}</option>
                                                  @endforeach
                                        </select>
                                    </div>
                                </div>
                                {!! form::submit('Add Club',[' class'=>'btn btn-primary form-control'])!!}
                             
                           

                            </fieldset>
                        {!! Form::close()!!}
                    </div>
                </div>

        </div>
    </div>
</div><!-- /col-lg-9 END SECTION MIDDLE -->
@stop

