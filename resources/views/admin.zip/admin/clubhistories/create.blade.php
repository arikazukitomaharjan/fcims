@extends('adminMaster')


@section('adminContent')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center><b>Add Player</b></center></div>

                    <div class="panel-body">
                            {!! Form::open(['route'=>'clubhistories.store'])!!}
                            <fieldset>
                                <div>
                                    <label><b>CLUB</b></label>
                                    <select class="form-control" name="club_id">
                                              @foreach($club as $club)
                                                <option value="{{$club->id}}">{{$club->name}}</option>
                                              @endforeach
                                    </select>
                                </div>
                                <div>
                                    <label><b>CLUB</b></label>
                                    <select class="form-control" name="championship_id">
                                              @foreach($championship as $championship)
                                                <option value="{{$championship->id}}">{{$championship->championship_name}}</option>
                                              @endforeach
                                    </select>
                                </div>
                                 <div class="form-group">
                                     <label><b>DOB</b></label>
                                     {!! Form::text('game_result_status',null,array('class'=>'form-control')) !!}
                                 </div>
                                 
                                <br><br>
                                <center>{!! form::submit('Add Club',[' class'=>'btn btn-primary form-control'])!!}</center>

                            </fieldset>
                        {!! Form::close()!!}
                    </div>
                </div>

        </div>
    </div>
</div><!-- /col-lg-9 END SECTION MIDDLE -->
@stop

